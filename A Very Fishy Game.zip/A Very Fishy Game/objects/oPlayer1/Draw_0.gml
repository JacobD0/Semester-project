draw_self();

if (shock_timer > 0)
{
    var f = floor(current_time / 80) mod sprite_get_number(sShock);
    draw_sprite(sShock, f, x, y);
}

//if (distance_to_object(oSquid1) <= 50)
//{
//	var f = floor(current_time / 80) mod sprite_get_number(sprSquidInk);
//	for(i=1;i<=10;i++){draw_sprite(sprSquidInk, f, x, y);}

//}	