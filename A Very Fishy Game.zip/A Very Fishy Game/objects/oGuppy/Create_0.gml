event_inherited();  // VERY IMPORTANT
reward_damage = 1;
size_rank = 18;
hp = 2;
damage = 0;
move_speed = 0.6;
chase_enabled = true;