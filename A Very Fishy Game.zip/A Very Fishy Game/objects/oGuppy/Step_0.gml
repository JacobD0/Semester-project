event_inherited();

var dir = sign(x - xprevious);

if (dir != 0) {
    image_xscale = dir;
}
// keeps fish within bounaderies of maps
x = clamp(x, 0, room_width);
y = clamp(y, 0, room_height);