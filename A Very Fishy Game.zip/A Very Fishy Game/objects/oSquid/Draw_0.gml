draw_self();
if (distance_to_object(oPlayer1) <= 75 || distance_to_object(oPlayer2) <= 75)
{
	var f = floor(current_time / 80) mod sprite_get_number(sprSquidInk);
    for(i=1;i<=10;i++){draw_sprite(sprSquidInk, f, x, y);}
}	