event_inherited();  // VERY IMPORTANT
reward_damage = 5;
size_rank = 3;
hp = 50;
damage = 2;
move_speed = .6;