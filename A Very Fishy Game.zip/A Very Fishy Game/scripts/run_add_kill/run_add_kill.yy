{
  "$GMScript":"v1",
  "%Name":"run_add_kill",
  "isCompatibility":false,
  "isDnD":false,
  "name":"run_add_kill",
  "parent":{
    "name":"A Very Fishy Game",
    "path":"A Very Fishy Game.yyp",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}