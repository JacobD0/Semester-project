{
  "$GMScript":"v1",
  "%Name":"Camera_at_Runtime",
  "isCompatibility":false,
  "isDnD":false,
  "name":"Camera_at_Runtime",
  "parent":{
    "name":"A Very Fishy Game",
    "path":"A Very Fishy Game.yyp",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}