{
  "$GMScript":"v1",
  "%Name":"run_finish",
  "isCompatibility":false,
  "isDnD":false,
  "name":"run_finish",
  "parent":{
    "name":"A Very Fishy Game",
    "path":"A Very Fishy Game.yyp",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}