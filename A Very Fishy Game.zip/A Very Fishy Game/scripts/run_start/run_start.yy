{
  "$GMScript":"v1",
  "%Name":"run_start",
  "isCompatibility":false,
  "isDnD":false,
  "name":"run_start",
  "parent":{
    "name":"A Very Fishy Game",
    "path":"A Very Fishy Game.yyp",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}